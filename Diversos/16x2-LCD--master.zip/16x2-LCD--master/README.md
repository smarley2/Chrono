# 16x2-LCD-
Library and example files for 8 bit mode interfacing of 16x2 LCD with C2000 F28027 (DSC)
